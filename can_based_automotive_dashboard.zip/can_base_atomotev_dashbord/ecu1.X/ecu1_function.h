#ifndef ECU1_FUNCTION_H
#define	ECU1_FUNCTION_H

#include <stdint.h>
#include <xc.h>

#define MAX_GEAR 7
#define SPEED_ADC_CHANNEL   0x04
#define GEAR_UP             SWITCH1
#define GEAR_DOWN           SWITCH2
#define COLLISION           SWITCH3

unsigned int get_speed();
unsigned char get_gear_pos(unsigned char gear);

#endif	/* ECU1_FUNCTION_H */