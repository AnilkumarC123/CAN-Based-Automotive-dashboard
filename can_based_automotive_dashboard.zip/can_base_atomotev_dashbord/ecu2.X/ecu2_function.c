/*
 * File:   ecu2_function.c
 * Author: Rajesh
 *
 * Created on 31 March, 2026, 11:18 AM
 */

#include "ecu2_function.h"
#include "digital_keypad.h"
#include "ssd.h"
#include "adc.h"

static unsigned int count = 0;

static unsigned char key = ALL_RELEASED;
static unsigned char prev = ALL_RELEASED;

static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {x, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};

unsigned int get_rpm()
{
    //Implement the rpm function
    
    unsigned int adc_val = 0, rpm = 0;
    
    adc_val = read_adc(CHANNEL4);
    rpm = ((unsigned long)adc_val * 6000) / 1023;
    
    ssd[0] = digit[rpm/1000];
    ssd[1] = digit[(rpm/100) % 10];
    ssd[2] = digit[(rpm/10) % 10];
    ssd[3] = digit[rpm % 10];
    
    display(ssd);
    return rpm;
}

unsigned char process_indicator(unsigned char ind)
{
    //Implement the indicator function
    
    key = read_digital_keypad(STATE_CHANGE);
        
    if(key != ALL_RELEASED)
    {
        count = 0;
        prev = key; 
    }

    if(prev == SWITCH1)
    {
        count++;
        if(count < 1000)
            PORTB = 0X0F;
        else
            PORTB = 0X00;

        if(count >= 2000)
            count = 0;
        
        return 1;
    }
    else if(prev == SWITCH2)
    {
        count++;
        if(count < 1000)
            PORTB = 0XF0;
        else
            PORTB = 0X00;

        if(count >= 2000)
            count = 0;
        
        return 2;
    }
    else if(prev == SWITCH3)
    {
        count++;
        if(count < 1000)
            PORTB = 0XFF;
        else
            PORTB = 0X00;

        if(count >= 2000)
            count = 0;
        
        return 3;
    }
    else if(prev == SWITCH4)
    {
        PORTB = 0X00;
        count = 0;
        
        return 4;
    }
    
    return ind;
}