/*
 * File:   main.c
 * Author: Rajesh
 *
 * Created on 17 March, 2026, 2:52 PM
 */


#include "matrix_keypad.h"
#include "clcd.h"
#include "adc.h"
#include "can.h"
#include "ecu1_function.h"
#include "msg_id.h"

unsigned int speed = 0;
unsigned char gear = 0;
unsigned char tx_data[2];
unsigned char *gear_box[MAX_GEAR] = {"NEUTRAL", "GEAR-1", "GEAR-2", "GEAR-3", "GEAR-4", "GEAR-5", "REVERSE"};

unsigned int rx_msg_id;
unsigned char rx_data[8];
unsigned char len = 0;

void main(void) 
{
    init_matrix_keypad();
    init_clcd();
    init_adc();
    init_can();
    while(1)
    {
        gear = get_gear_pos(gear);        
        speed = get_speed();
        
        clcd_print(gear_box[gear], LINE2(0));
        
        tx_data[0] = speed;
        tx_data[1] = gear;

       can_transmit(SPEED_MSG_ID,tx_data,2);

       can_receive(&rx_msg_id,rx_data,&len);
    }
    return;
}