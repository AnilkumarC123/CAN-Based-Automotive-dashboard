/*
 * File:   main.c
 * Author: Rajesh
 *
 * Created on 17 March, 2026, 2:52 PM
 */


#include "adc.h"
#include "ssd.h"
#include "can.h"
#include "digital_keypad.h"
#include "ecu2_function.h"
#include "msg_id.h"

unsigned int rpm;
unsigned char tx_data[2];
unsigned char ind = 0;

unsigned int rx_msg_id;
unsigned char rx_data[8];
unsigned char len;

void main(void) 
{
    TRISB = 0;
    PORTB = 0;
    
	init_digital_keypad();
    init_ssd_control();
    init_adc();
    init_can();
    
    while(1)
    {
        ind = process_indicator(ind);       
        rpm = get_rpm();
        
        tx_data[0] = rpm;
        tx_data[1] = ind;

        can_transmit(SPEED_MSG_ID, tx_data, 3);

        can_receive(&rx_msg_id,rx_data,&len);
    }
    return;
}