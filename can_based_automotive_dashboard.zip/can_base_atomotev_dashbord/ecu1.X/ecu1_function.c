/*
 * File:   functions.c
 * Author: Rajesh
 *
 * Created on 31 March, 2026, 10:15 AM
 */


#include <xc.h>
#include "matrix_keypad.h"
#include "adc.h"
#include "clcd.h"
#include "ecu1_function.h"

unsigned char get_gear_pos(unsigned char gear)
{
    unsigned char key = read_switches(STATE_CHANGE);
    
    if(key == MK_SW1 && gear < 5)
    {
        CLEAR_DISP_SCREEN;
        return ++gear;
    }
    else if(key == MK_SW2 && gear > 0)
    {
        CLEAR_DISP_SCREEN;
        return --gear;
    }
    else if(key == MK_SW3)
    {
        CLEAR_DISP_SCREEN;
        return 6;
    }
    return gear;
}

unsigned int get_speed()
{
    unsigned int adc_val = read_adc(CHANNEL4);
    unsigned int speed = ((unsigned long)adc_val * 99) / 1023;
    
    clcd_print("speed - ", LINE1(0));
    clcd_putch((speed / 10) + '0', LINE1(8));
    clcd_putch((speed % 10) + '0', LINE1(9));
    clcd_print("KMPH", LINE1(11));
    
    return speed;
}